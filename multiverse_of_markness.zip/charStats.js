import {CONSTANTS} from "./constants.js"

export const stats = {
  "mark": 
  {
    name: "mark",
    hp: 3, 
    atk: 2, 
    speed: 150,
    bio: "Oh hi",
  },
  "markbot":
  {
    name: "markbot",
    hp: 3,
    atk: 2,
    speed: 150,
    bio: "Beep boop beep",
  },
  "viking":
  {
    name: "viking mark",
    hp: 3,
    atk: 2, 
    speed: 150,
    bio: "By the moons of Mars, my smile conquers the cosmos!"
  },
}